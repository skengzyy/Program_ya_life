package Accounting;
/**
 * This is an Item
 * @author Isaac Jerryson
 * @version 14.03.2024
 */
public class Stepper1 {
    public static void main(String[] args) {
        // Test Item
        Item item1 = new Item("Book", 15.99);
        Item item2 = new Item("Pen", 2.49);

        System.out.println("Item 1: " + item1.itemData());
        System.out.println("Item 2: " + item2.itemData());

        // Test Account
        Account account = new Account(123456, 100.0, 5);
        System.out.println("\nInitial Account Details:");
        System.out.println(account);

        // Test buying items
        System.out.println("\nBuying Item 1:");
        boolean boughtItem1 = account.buyItem(item1);
        if (boughtItem1) {
            System.out.println("Item 1 bought successfully.");
        } else {
            System.out.println("Failed to buy Item 1.");
        }
        System.out.println("Updated Account Details:");
        System.out.println(account);

        System.out.println("\nBuying Item 2:");
        boolean boughtItem2 = account.buyItem(item2);
        if (boughtItem2) {
            System.out.println("Item 2 bought successfully.");
        } else {
            System.out.println("Failed to buy Item 2.");
        }
        System.out.println("Updated Account Details:");
        System.out.println(account);

        // Test invalid item purchase
        System.out.println("\nTrying to buy Item 1 again:");
        boolean boughtItem1Again = account.buyItem(item1);
        if (boughtItem1Again) {
            System.out.println("Item 1 bought successfully.");
        } else {
            System.out.println("Failed to buy Item 1 again.");
        }
        System.out.println("Updated Account Details:");
        System.out.println(account);
    }
}
