package Accounting;

/**
 * This is Premium-Account
 * @author Isaac Jerryson
 * @version 15.03.2024
 */
public class PremiumAccount extends Account {
    private double premiumFee;
    private double discountRate;
    private boolean feeCharged;

    public PremiumAccount(int accountId, double balance, int positions, double premiumFee, double discountRate, boolean feeCharged) {
        super(accountId, balance, positions);
        setPremiumFee(premiumFee);
        setDiscountRate(discountRate);
        setFeeCharged(feeCharged);
    }

    public double getPremiumFee() {
        return this.premiumFee;
    }

    public void setPremiumFee(double premiumFee) {
        if (premiumFee >= 1.0) this.premiumFee = premiumFee;
        else System.out.println("Ungültiger Premium Preis"); this.premiumFee = 1.0;

    }

    public double getDiscountRate() {
        return this.discountRate;
    }

    public void setDiscountRate(double discountRate) {
        if (discountRate >= 0.0 && discountRate <= 100.0) this.discountRate = discountRate;
        else this.discountRate = 0.0;

    }

    public boolean isFeeCharged() {
        return this.feeCharged;
    }

    public void setFeeCharged(boolean feeCharged) {
        this.feeCharged = feeCharged;
    }

    public void chargeMonthly() {
        if (!feeCharged && getBalance() >= premiumFee) {
            setBalance(getBalance() - premiumFee);
            setFeeCharged(true);
        }
    }

    @Override
    public boolean buyItem(Item item) {
        if (item != null) {
            if (getBalance() >= item.getCost()) {
                for (int i = 0; i < getInventory().length; i++) {
                    if (getInventory()[i] == null) {
                        getInventory()[i] = item;
                        setBalance(getBalance() - (item.getCost() * (getDiscountRate() / 100)));
                        return true;
                    }
                }
            }
            System.err.println("Sie haben nicht genügend Guthaben für dieses Item.");
            return false;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Account-Data: \n" + super.toString() + "\nPremium-Account: \nPremium-Fee: " + getPremiumFee() + "\nDiscount-Rate: " + getDiscountRate() + "% \nFee-Charged: " + isFeeCharged();
    }
}
